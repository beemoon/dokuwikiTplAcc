<?php
/*
 * Default configuration settings
 *
 * @author   beemoon <contact@beemoon.fr>
 * @license  GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

$conf['enableAccordion']          = 1;
$conf['topSidebar']	=	'';
$conf['bottomSidebar']	= '';
