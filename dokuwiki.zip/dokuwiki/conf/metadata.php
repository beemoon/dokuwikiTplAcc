<?php
/*
 * configuration metadata
 *
 * @author   beemoon <contact@beemoon.fr>
 * @license  GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */


// Theme
$meta['enableAccordion']  = array('onoff');
$meta['topSidebar']	=	array('string');
$meta['bottomSidebar']	=	array('string');

