<?php
$lang['enableAccordion']   = 'enable Accordion JQuery in sidebar (Desktop version only)';
$lang['topSidebar']   = 'Top sidebar page name (if template supports it), empty field disables the top sidebar';
$lang['bottomSidebar']   = 'Bottom sidebar page name (if template supports it), empty field disables the bottom sidebar';
