<?php
$lang['enableAccordion']   = 'enable Accordion JQuery in sidebar (Desktop version only)';
