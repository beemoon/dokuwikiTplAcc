<?php
$lang['enableAccordion']   = 'Activer le menu Accordion JQuery dans la sidebar (version Desktop)';
